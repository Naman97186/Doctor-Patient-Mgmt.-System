package com.xcelore.doctor_app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.xcelore.doctor_app.entity.City;
import com.xcelore.doctor_app.entity.Doctor;
import com.xcelore.doctor_app.entity.Patient;
import com.xcelore.doctor_app.entity.Speciality;
import com.xcelore.doctor_app.entity.Symptom;
import com.xcelore.doctor_app.exception.PatientException;
import com.xcelore.doctor_app.repository.DoctorRepository;
import com.xcelore.doctor_app.repository.PatientRepository;

@Service
public class PatientService {

	@Autowired
	private PatientRepository patientRepository;
	@Autowired
	private DoctorRepository doctorRepository;
	
	public ResponseEntity<?> savePatient(Patient patient) {
		Patient save = patientRepository.save(patient);
		if(save!=null)
		return ResponseEntity.ok(patientRepository.save(patient));
		else
			throw new PatientException("patient record not saved");
	}
	
	public ResponseEntity<String> removePatient(Patient patient) {
		 
			Optional<Patient> byId = patientRepository.findById(patient.getPatientId());
			if(byId.isPresent()) {
		   patientRepository.deleteById(patient.getPatientId());
		
			return new ResponseEntity<String>("patient remove Sucessfully",HttpStatus.OK);
	}
			else {
			throw new PatientException("patient record not found");
			}
	}

	public ResponseEntity<?> suggestPatient(long patientId) {
	     Optional<Patient> optional = patientRepository.findById(patientId);
	     if(optional.isPresent()) {
	    	 Patient patient=optional.get();
	    	 String symptom = patient.getSymptom().toUpperCase();
	    	 String city=patient.getCity();
	    	 List<Doctor> byCity = doctorRepository.findByCity(City.valueOf(city.toUpperCase()));
	    	 if(byCity!=null) {
	    		 if(symptom.equals("ARTHRITIS") ||symptom.equals("BACK PAIN") ||symptom.equals("TISSUE INJURY")) {
	    			List< Doctor> doctor = doctorRepository.findBySpeciality(Speciality.ORTHOPAEDIC);
	    			 return new ResponseEntity<>(doctor,HttpStatus.OK); 
	    		 }
	    		 else if(symptom.equals("DYSMENORRHEA") ) {
		    			List< Doctor> doctor = doctorRepository.findBySpeciality(Speciality.GYNECOLOGY);
		    			 return new ResponseEntity<>(doctor,HttpStatus.OK); 
		    		 }
	    		 else if(symptom.equals("SKIN INFECTION")|| symptom.equals("SKIN BURN") ) {
		    			List< Doctor> doctor = doctorRepository.findBySpeciality(Speciality.DERMATOLOGY);
		    			 return new ResponseEntity<>(doctor,HttpStatus.OK); 
		    		 }
	    		 else if(symptom.equals("EAR PAIN") ) {
		    			List< Doctor> doctor = doctorRepository.findBySpeciality(Speciality.ENT);
		    			 return new ResponseEntity<>(doctor,HttpStatus.OK); 
		    		 }
	    		 else {
	    			 throw new PatientException("There isn't any doctor present at your location for your sympton");
	    		 }
	    		 
	    	 }
	    	 else {
	    		 throw new PatientException("we are still waiting to expand to your location");  
	    	 }
	     }
	     else{
	    	throw new PatientException("patient record not found"); 
	     }
		
	}
	
}
