package com.xcelore.doctor_app.exception;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionHandling {

	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> exception(Exception e) {
		return new ResponseEntity<String>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> validException(MethodArgumentNotValidException e) {
		List<ObjectError> allErrors = e.getAllErrors();
		Map<String, String> map=new HashMap<String, String>();
		for (ObjectError objectError : allErrors) {
			FieldError error=(FieldError)objectError;
			map.put(error.getField(), objectError.getDefaultMessage());
		}
		return new ResponseEntity<Map<String, String>>(map,HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
