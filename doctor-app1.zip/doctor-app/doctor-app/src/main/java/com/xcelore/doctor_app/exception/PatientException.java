package com.xcelore.doctor_app.exception;

public class PatientException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String message;

	public PatientException(String message) {
		
		this.message = message;
	}
	
     @Override
    public String getMessage() {
    	
    	return message;
    }
}
