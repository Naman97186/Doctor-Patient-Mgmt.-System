package com.xcelore.doctor_app.entity;

public enum City {
  DELHI,NOIDA,FARIDABAD;
}
