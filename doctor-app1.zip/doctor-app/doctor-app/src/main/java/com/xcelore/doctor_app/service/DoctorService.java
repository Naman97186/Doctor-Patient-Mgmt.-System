package com.xcelore.doctor_app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.xcelore.doctor_app.entity.Doctor;
import com.xcelore.doctor_app.exception.DoctorException;
import com.xcelore.doctor_app.exception.PatientException;
import com.xcelore.doctor_app.repository.DoctorRepository;

@Service
public class DoctorService {

	@Autowired
	private DoctorRepository doctorRepository;
	
	public ResponseEntity<?> savePatient(Doctor doctor) {
		
		Doctor save = doctorRepository.save(doctor);
		if(save!=null)
		return ResponseEntity.ok(save);
		else {
			throw new DoctorException("data not saved");
		}
	}
	public ResponseEntity<String> removeDoctor(Doctor doctor) {
		
		Optional<Doctor> byId = doctorRepository.findById(doctor.getDoctorId());
		if(byId.isPresent()) {
			doctorRepository.deleteById(doctor.getDoctorId());
	
		return new ResponseEntity<String>("doctor remove Sucessfully",HttpStatus.OK);
}
		else {
		throw new PatientException("doctor record not found");
		}
	}
}
