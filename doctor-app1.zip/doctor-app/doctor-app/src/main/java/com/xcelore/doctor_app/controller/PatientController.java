package com.xcelore.doctor_app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.xcelore.doctor_app.entity.Patient;
import com.xcelore.doctor_app.service.PatientService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/app")
public class PatientController {

	@Autowired
	private PatientService patientService;
	@Operation(description = "Retrieve user record in database" ,summary = "api used to show user details if user details show, it give response ok or give internal server error \n city and symptoms should should be in upper case are you will get parsing exception")
	@ApiResponses(value = {@ApiResponse(description = "sucessfull save",responseCode = "200"),
			@ApiResponse(description = "Not saved",responseCode = "500")})
	@PostMapping("/patient")
	public ResponseEntity<?> savePatient(@Valid @RequestBody Patient patient) {
		return patientService.savePatient(patient);
	}
	@Operation(description = "Delete user record in database" ,summary = "api used to delete user details if user details delete, it give response ok or give internal server error \n city and symptoms should should be in upper case are you will get parsing exception")
	@ApiResponses(value = {@ApiResponse(description = "sucessfull save",responseCode = "200"),
			@ApiResponse(description = "Not saved",responseCode = "500")})
	@DeleteMapping("/patient")
	public ResponseEntity<?> removePatient(@Valid @RequestBody Patient patient) {
		return patientService.removePatient(patient);
	}
	@Operation(description = "save user record in database" ,summary = "api used to save user details if user details save it give response ok or give internal server error \n city and symptoms should should be in upper case are you will get parsing exception")
	@ApiResponses(value = {@ApiResponse(description = "sucessfull save",responseCode = "200"),
			@ApiResponse(description = "Not saved",responseCode = "500")})
	@GetMapping("/patient")
	public ResponseEntity<?> suggestDoctor(@RequestParam long patientId){
		return patientService.suggestPatient(patientId);
	}
}
