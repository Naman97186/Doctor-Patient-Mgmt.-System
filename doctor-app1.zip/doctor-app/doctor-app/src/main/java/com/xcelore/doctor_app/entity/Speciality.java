package com.xcelore.doctor_app.entity;

public enum Speciality {
 ORTHOPAEDIC,GYNECOLOGY,DERMATOLOGY,ENT
}
