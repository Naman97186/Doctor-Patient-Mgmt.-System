package com.xcelore.doctor_app.entity;

public enum Symptom {

	ARTHRITIS,BACKPAIN,TISSUEINJURIES,DYSMENORRHEA,SKIN_INFECTION,SKIN_BURN,
	EAR_PAIN
}
