package com.xcelore.doctor_app.exception;

public class DoctorException extends RuntimeException {

	private String message;

	public DoctorException(String message) {
		
		this.message = message;
	}
	
	@Override
	public String getMessage() {
		
		return message;
	}
}
