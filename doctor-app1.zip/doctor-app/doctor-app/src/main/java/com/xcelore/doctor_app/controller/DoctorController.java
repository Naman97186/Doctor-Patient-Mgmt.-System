package com.xcelore.doctor_app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xcelore.doctor_app.entity.Doctor;
import com.xcelore.doctor_app.service.DoctorService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/app")
public class DoctorController {

	@Autowired
	private DoctorService doctorService;
	@Operation(description = "save doctor record in database" ,summary = "api used to save doctor details if doctor details save it give response ok or give internal server error \n city and symptoms should should be in upper case are you will get parsing exception")
	@ApiResponses(value = {@ApiResponse(description = "sucessfull save",responseCode = "200"),
			@ApiResponse(description = "Not saved",responseCode = "500")})
	@PostMapping("/doctor")
	public ResponseEntity<?> saveDoctor(@Valid @RequestBody Doctor doctor) {
		return doctorService.savePatient(doctor);
	}
	@Operation(description = "Delete doctor record in database" ,summary = "api used to delete doctor details if doctor details save it give response ok or give internal server error \n city and symptoms should should be in upper case are you will get parsing exception")
	@ApiResponses(value = {@ApiResponse(description = "sucessfull save",responseCode = "200"),
			@ApiResponse(description = "Not saved",responseCode = "500")})
	@DeleteMapping("/doctor")
	public ResponseEntity<?> deleteDoctor( @RequestBody Doctor doctor) {
		return doctorService.removeDoctor(doctor);
	}
}
