package com.xcelore.doctor_app.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.xcelore.doctor_app.entity.City;
import com.xcelore.doctor_app.entity.Doctor;
import com.xcelore.doctor_app.entity.Speciality;


@Repository
public interface DoctorRepository extends JpaRepository<Doctor,Long>{

	List<Doctor> findByCity(City city);

	List<Doctor> findBySpeciality(Speciality speciality);

}
